# Saboteur Check-in (Android and iOS app)

PI-inspired Saboteur assessments (5 tests, 52 questions each). The app is the web page in `www/index.html`
wrapped as a native app with Capacitor. Original statements written for a course assignment; not the official
Positive Intelligence assessment and not a diagnostic or clinical tool.

## Where to edit
- `www/index.html`  : the whole app (questions, scoring, feedback, design). See the editing guide at the top of its script.
- `www/index.html`  line with `const SAVE_URL = "";` : paste your Google Apps Script link to save results to Google Sheets.
- `capacitor.config.json` : app name and app ID (`appId`). Change the app ID to your own before publishing to a store.
- `assets/` : icon and splash source images (1024 and 2732 px). Re-run `npx capacitor-assets generate` after changing them.

## After any change to www/
    npx cap sync

## Build an Android APK without installing anything (GitHub Actions)
1. Put these files in a GitHub repository.
2. Open the Actions tab > "Build Android APK" > Run workflow.
3. When it turns green, open the run and download "saboteur-checkin-debug-apk" (a zip containing app-debug.apk).
4. Unzip it, copy app-debug.apk to your Android phone, open it, and allow "install unknown apps" when asked.

## Build on your own computer
Requirements: Node.js 22 or newer, Java 21.

    npm install
    npx cap sync

Android (Windows, Mac, or Linux): install Android Studio, then `npx cap open android` and press Run.
iPhone (Mac only): install Xcode, then `npx cap open ios`, choose your team under Signing & Capabilities, and press Run.
